# Sauna Performance Analysis

## Overview

This project analyzes temperature and humidity data from sauna measurements to understand heating and cooling performance characteristics. The analysis identifies individual sauna cycles, measures heating/cooling rates, and tracks humidity changes throughout each session.

## Files

- `sauna_analysis.py` - Main analysis script
- `Sauna.csv` - Input data file (Date, Temperature, Humidity)
- `output/saunastats.png` - Generated analysis visualization

## How It Works

### 1. Data Loading
The script loads the `Sauna.csv` file containing timestamped measurements of temperature (°C) and relative humidity (%). The data spans multiple sauna sessions over time.

### 2. Baseline Temperature Calculation
The baseline (room) temperature is computed as the average of the lowest 10% of temperature readings:
- This represents the ambient temperature when no sauna heating is occurring
- Example: ~18.85°C

### 3. Cycle Detection
The algorithm identifies individual sauna heating/cooling cycles:

```
1. Start at baseline temperature
2. Detect when temperature rises above baseline + threshold (heating starts)
3. Track to the peak temperature (hottest point)
4. Continue tracking until temperature returns near baseline (cooling ends)
5. Record one complete cycle
6. Repeat until all data is processed
```

**Key Parameters:**
- `HEATING_THRESHOLD = 2.0°C` - Temperature above baseline to detect heating
- `COOLING_THRESHOLD = 1.5°C` - Temperature above baseline to detect cooling end

### 4. Metrics Calculation

For each detected cycle, the script calculates:

#### Heating Phase
- **Heating Duration**: Time from start to peak temperature (in seconds)
- **Heating Rate**: Temperature increase rate (°C/second)
- Calculated using linear regression on the heating segment

#### Cooling Phase
- **Cooling Duration**: Time from peak to baseline return (in seconds)
- **Cooling Rate**: Temperature decrease rate (°C/second)
- Calculated using linear regression on the cooling segment

#### Humidity
- **Humidity Peak**: Maximum humidity during the heating phase (%)
- Tracks how humidity changes as the sauna heats up

### 5. Statistical Analysis

The script computes variance metrics using the **Coefficient of Variation (CV%)**:

```
CV = (Standard Deviation / Mean) × 100%
```

This provides a dimensionless measure of variability that can be compared across different metrics:
- Heating rate CV%
- Cooling rate CV%
- Heating duration CV%
- Cooling duration CV%
- Humidity peak CV%

### 6. Visualization

The output plot (`saunastats.png`) contains 6 panels:

| Panel | Description |
|-------|-------------|
| 1 | Temperature and humidity over time with cycle markers |
| 2 | Heating rate analysis with mean ±1σ error bands |
| 3 | Cooling rate analysis with mean ±1σ error bands |
| 4 | Comparison of heating vs cooling duration per cycle |
| 5 | Humidity peak during heating phase |
| 6 | Scientific variance analysis (CV%) for all metrics |

## Example Output

```
============================================================
SAUNA PERFORMANCE ANALYSIS SUMMARY
============================================================

Baseline Temperature: 18.85 °C
Cycles Detected: 73

--- Heating Analysis ---
  Mean Heating Rate: 0.000741 °C/s
  Std Dev: 0.001097 °C/s
  CV: 148.13%
  Mean Heating Duration: 134973.15 seconds (~37 hours)
  Std Dev: 499882.28 seconds

--- Cooling Analysis ---
  Mean Cooling Rate: -0.000046 °C/s
  Std Dev: 0.000045 °C/s
  CV: -96.83%
  Mean Cooling Duration: 279687.52 seconds (~78 hours)
  Std Dev: 602239.83 seconds

--- Humidity Analysis ---
  Mean Peak Humidity: 42.64%
  Std Dev: 12.64%
  CV: 29.64%
```

## Key Findings

- **Heating time is significantly shorter than cooling time** - This is expected as heating uses active heat sources while cooling happens passively
- **High CV values** indicate variability in sauna usage patterns (different session lengths, temperatures reached, etc.)
- **Humidity correlation** shows how moisture content changes during heating phases

## Usage

```bash
# Ensure you're in the project directory
cd /home/lab/projects/rouvi

# Run the analysis
source venv/bin/activate
python sauna_analysis.py
```

The script will:
1. Load `Sauna.csv`
2. Detect heating/cooling cycles
3. Calculate all metrics
4. Generate `output/saunastats.png`
5. Print a summary to stdout

## Requirements

### Python Packages

```bash
# Install dependencies (using venv is recommended)
pip install pandas numpy matplotlib scipy
```

Or use the provided virtual environment:

```bash
source venv/bin/activate
pip install pandas numpy matplotlib scipy
```

### System Requirements

- Python 3.8 or higher
- Minimum 100MB disk space for output files

## Notes

- The analysis is designed to work with sparse sampling intervals (minutes between readings)
- The cycle detection is adaptive and doesn't require fixed sampling rates
- Variance is expressed as Coefficient of Variation (%) for scientific comparison across metrics with different units